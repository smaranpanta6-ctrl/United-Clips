import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
    MessageFlags,
    PermissionFlagsBits
} from "discord.js";

import {
    getCampaign,
    saveCampaign
} from "../utils/database.js";

import {
    getSubmission,
    reviewSubmission
} from "./submissionService.js";

import {
    appendSubmissionReview
} from "../utils/googleSheets.js";

const STAFF_ROLE_ID =
    process.env.STAFF_ROLE_ID ||
    "1529961495402778771";

function isStaff(interaction) {
    return Boolean(
        interaction.memberPermissions?.has(
            PermissionFlagsBits.ManageGuild
        ) ||
        interaction.member?.roles?.cache?.has(
            STAFF_ROLE_ID
        )
    );
}

function updatedReviewEmbed(
    message,
    status,
    rejectionReason,
    reviewerTag
) {
    const original = message.embeds?.[0];
    const embed = original
        ? EmbedBuilder.from(original)
        : new EmbedBuilder().setTitle("Clip Submission");

    const fields = (original?.fields || [])
        .filter(field => field.name !== "Rejection Reason")
        .map(field => {
            if (field.name === "Status") {
                return {
                    name: field.name,
                    value:
                        status === "approved"
                            ? "🟢 Approved"
                            : "🔴 Rejected",
                    inline: field.inline
                };
            }

            return {
                name: field.name,
                value: field.value,
                inline: field.inline
            };
        });

    if (status === "rejected" && rejectionReason) {
        fields.push({
            name: "Rejection Reason",
            value: rejectionReason,
            inline: false
        });
    }

    embed
        .setFields(fields)
        .setColor(
            status === "approved"
                ? 0x57f287
                : 0xed4245
        )
        .setFooter({
            text: `${status === "approved" ? "Approved" : "Rejected"} by ${reviewerTag}`
        })
        .setTimestamp();

    return embed;
}

function activeReviewButtons(submissionId, status) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`submission_approve_${submissionId}`)
            .setLabel(
                status === "approved"
                    ? "Approved — click to confirm again"
                    : "Approve"
            )
            .setEmoji("✅")
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId(`submission_reject_${submissionId}`)
            .setLabel(
                status === "rejected"
                    ? "Rejected — change reason"
                    : "Reject"
            )
            .setEmoji("❌")
            .setStyle(ButtonStyle.Danger)
    );
}

function adjustCampaignCounters(campaign, previousStatus, nextStatus) {
    if (!campaign || previousStatus === nextStatus) {
        return;
    }

    const decrement = key => {
        campaign[key] = Math.max(
            0,
            Number(campaign[key] || 0) - 1
        );
    };

    const increment = key => {
        campaign[key] = Number(campaign[key] || 0) + 1;
    };

    if (previousStatus === "pending") {
        decrement("pendingSubmissions");
    } else if (previousStatus === "approved") {
        decrement("approvedSubmissions");
    } else if (previousStatus === "rejected") {
        decrement("rejectedSubmissions");
    }

    if (nextStatus === "approved") {
        increment("approvedSubmissions");
    } else if (nextStatus === "rejected") {
        increment("rejectedSubmissions");
    }
}

async function sendCreatorDm({
    client,
    submission,
    campaign,
    status,
    rejectionReason
}) {
    try {
        const user = await client.users.fetch(submission.user_id);

        const embed = new EmbedBuilder()
            .setColor(
                status === "approved"
                    ? 0x57f287
                    : 0xed4245
            )
            .setTitle(
                status === "approved"
                    ? "✅ Submission Approved"
                    : "❌ Submission Rejected"
            )
            .setDescription(
                status === "approved"
                    ? "Your clip has been approved by the United Clips staff."
                    : "Your clip was reviewed and rejected. You can submit a corrected version while the campaign is active."
            )
            .addFields(
                {
                    name: "Campaign",
                    value: campaign?.name || submission.campaign_id,
                    inline: true
                },
                {
                    name: "Submission",
                    value: `#${submission.id}`,
                    inline: true
                },
                {
                    name: "Platform",
                    value: submission.platform || "Not specified",
                    inline: true
                },
                {
                    name: "Video",
                    value: submission.video_url,
                    inline: false
                }
            )
            .setFooter({
                text: "United Clips • Campaign Review"
            })
            .setTimestamp();

        if (status === "rejected") {
            embed.addFields({
                name: "Reason",
                value: rejectionReason || "No reason provided",
                inline: false
            });
        }

        await user.send({ embeds: [embed] });
    } catch (error) {
        console.warn(
            `Could not DM creator ${submission.user_id}:`,
            error?.message || error
        );
    }
}

export async function finalizeSubmissionReview({
    interaction,
    client,
    submissionId,
    status,
    rejectionReason = null,
    staffNotes = null,
    reviewChannelId = null,
    reviewMessageId = null
}) {
    if (!isStaff(interaction)) {
        const payload = {
            content: "❌ Only staff can review submissions.",
            flags: MessageFlags.Ephemeral
        };

        if (interaction.deferred || interaction.replied) {
            await interaction.followUp(payload);
        } else {
            await interaction.reply(payload);
        }
        return null;
    }

    const submission = await getSubmission(client, submissionId);

    if (!submission) {
        throw new Error(`Submission #${submissionId} was not found.`);
    }

    const previousStatus = submission.status || "pending";

    const reviewed = await reviewSubmission(client, {
        submissionId,
        status,
        reviewedBy: interaction.user.id,
        rejectionReason,
        staffNotes
    });

    if (!reviewed) {
        throw new Error(`Submission #${submissionId} could not be updated.`);
    }

    const campaign = await getCampaign(
        client,
        submission.campaign_id
    );

    if (campaign) {
        adjustCampaignCounters(campaign, previousStatus, status);

        await saveCampaign(client, campaign.id, campaign);

        if (campaign.googleSheetId) {
            try {
                const creator = await interaction.guild.members
                    .fetch(submission.user_id)
                    .catch(() => null);

                await appendSubmissionReview({
                    spreadsheetId: campaign.googleSheetId,
                    reviewedAt: reviewed.reviewed_at,
                    campaignName: campaign.name,
                    creatorName:
                        creator?.user?.tag || submission.user_id,
                    creatorId: submission.user_id,
                    videoUrl: submission.video_url,
                    platform: submission.platform,
                    status:
                        status === "approved"
                            ? "Approved"
                            : "Rejected",
                    rejectionReason,
                    reviewedBy: interaction.user.tag,
                    staffNotes:
                        previousStatus !== "pending"
                            ? `Decision changed from ${previousStatus} to ${status}${staffNotes ? ` — ${staffNotes}` : ""}`
                            : staffNotes,
                    submittedAt: submission.created_at,
                    submissionId: submission.id
                });
            } catch (sheetError) {
                console.error(
                    "Failed to append submission review to Google Sheet:",
                    sheetError
                );
            }
        }
    }

    let reviewMessage = interaction.message || null;

    if (
        reviewChannelId &&
        reviewMessageId &&
        (!reviewMessage || reviewMessage.id !== reviewMessageId)
    ) {
        const channel = await interaction.guild.channels
            .fetch(reviewChannelId)
            .catch(() => null);

        if (channel?.isTextBased()) {
            reviewMessage = await channel.messages
                .fetch(reviewMessageId)
                .catch(() => null);
        }
    }

    if (reviewMessage) {
        await reviewMessage.edit({
            embeds: [
                updatedReviewEmbed(
                    reviewMessage,
                    status,
                    rejectionReason,
                    interaction.user.tag
                )
            ],
            components: [
                activeReviewButtons(submission.id, status)
            ]
        });
    }

    await sendCreatorDm({
        client,
        submission,
        campaign,
        status,
        rejectionReason
    });

    const changed = previousStatus !== "pending";
    const confirmation =
        status === "approved"
            ? `✅ Submission #${submission.id} ${changed ? "changed to approved" : "approved"}.`
            : `❌ Submission #${submission.id} ${changed ? "changed to rejected" : "rejected"}: ${rejectionReason}`;

    await interaction.followUp({
        content: confirmation,
        flags: MessageFlags.Ephemeral
    });

    return reviewed;
}
